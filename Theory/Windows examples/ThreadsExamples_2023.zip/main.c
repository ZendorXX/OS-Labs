#include <stdio.h>
#include <stdlib.h>
#include "Examples.h"

int main()
{
	Example3();
	system("pause");
	return 0;
}