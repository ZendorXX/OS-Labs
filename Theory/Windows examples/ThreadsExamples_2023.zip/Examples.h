#ifndef EXAMPLES__H__
#define EXAMPLES__H__

void Example1();
void Example2();
void Example3();

#endif